import express from "express"
import { addDeposit, creataddwallet, getDepositTrans, manageStatus } from "../../controllers/Deposit-C/depositController.js"


const depositRouter = express.Router()


depositRouter.put("/add-deposit/:loginAuthId/:milestoneId/:taskId", addDeposit)

depositRouter.get("/manageStatus/:session_id", manageStatus)

depositRouter.put("/addtocard/:loginAuthId", creataddwallet)


depositRouter.get("/transtion-Details/:loginAuthId", getDepositTrans)









export default depositRouter