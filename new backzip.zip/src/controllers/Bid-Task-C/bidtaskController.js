import BidTask from "../../models/Bid-Task-M/bidTaskSchema.js";
import TaskSubcategory from "../../models/Task-M/Task-subcategory/task-subcategory-schema.js";


export const createBid = async (req, res) => {

    try {

        const { loginAuthId, taskId } = req.params;

        const { description, minimalRate, deliveryTime, deliveryDays } = req.body;

        const checkTask = await TaskSubcategory.findOne({ _id: taskId });

        if (!checkTask) {
            return res.status(404).json({
                message: "Task not found"
            });
        }

        const existingBid = await BidTask.findOne({ loginAuthId, taskId });

        if (existingBid) {
            const updatedBid = await BidTask.findOneAndUpdate(
                { loginAuthId, taskId },
                { description, minimalRate, deliveryTime, deliveryDays },
                { new: true }
            );

            return res.status(200).json({
                message: "Bid updated successfully",
                bidplace: updatedBid
            });
        }

        const newTaskCreate = new BidTask({
            loginAuthId, taskId, description, minimalRate, deliveryTime, deliveryDays, TaskCreaterId: checkTask.authId
        });

        await newTaskCreate.save();

        res.status(200).json({
            message: "Placed bid on task",
            bidplace: newTaskCreate
        });

    } catch (error) {
        res.status(500).json({
            message: "Internal server error"
        });
    }
};
