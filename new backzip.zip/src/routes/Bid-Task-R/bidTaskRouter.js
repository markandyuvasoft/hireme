import express from "express"
import { createBid } from "../../controllers/Bid-Task-C/bidtaskController.js"


const bidRouter = express.Router()

bidRouter.post("/createBid/:loginAuthId/:taskId", createBid)


export default bidRouter